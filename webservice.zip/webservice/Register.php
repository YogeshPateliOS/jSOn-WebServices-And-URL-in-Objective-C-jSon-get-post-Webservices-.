<?php  
    include 'Connection.php';
    
    $Name=  $_REQUEST["Name"];
    $Mobile=  $_REQUEST["Mobile"];
    $DOB=  $_REQUEST["DOB"];
    $Address=  $_REQUEST["Address"];

    $exe= $con->query("insert into register(name,mobile,dob,address) values('$Name','$Mobile','$DOB','$Address')");

    if($exe) echo "Data Inserted Successfully";
    else echo "something went worng";

