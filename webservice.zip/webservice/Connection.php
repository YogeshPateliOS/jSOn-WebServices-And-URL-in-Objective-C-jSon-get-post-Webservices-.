
<?php

$con = new mysqli("localhost","root","","webservice");

if($con->connect_error)
{
    echo $con->connect_error;
    exit;
}

?>